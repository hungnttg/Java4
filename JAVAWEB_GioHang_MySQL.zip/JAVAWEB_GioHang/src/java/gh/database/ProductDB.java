/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gh.database;

import gh.model.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mac
 */
public class ProductDB {
    public static List<Product> getAll()
    {
        List<Product> list = new ArrayList<>();
        String str = "SELECT * FROM Product";
        Connection connection = Util.getConnection();
        try {
            PreparedStatement ps = connection.prepareStatement(str);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                Product p = new Product();
                p.setCode(rs.getString("code"));
                p.setName(rs.getString("name"));
                p.setPrice(rs.getFloat("price"));
                list.add(p);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public static Product get(String code)
    {
        Product p=null;
        String sql = "SELECT * FROM Product WHERE code=?";
        Connection connection = Util.getConnection();
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,code);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                p = new Product();
                p.setCode(code);
                p.setName(rs.getString("name"));
                p.setPrice(rs.getFloat("price"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p;
    }
    
}

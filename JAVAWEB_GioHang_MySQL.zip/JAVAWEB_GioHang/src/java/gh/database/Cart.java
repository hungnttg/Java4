/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gh.database;

import gh.model.ProductCart;
import java.util.HashMap;


/**
 *
 * @author mac
 */
public class Cart extends HashMap{
    public Cart()
    {
        super();
    }
    public void addProd(ProductCart prod)
    {
        String key=prod.getProd().getCode();
        if(this.containsKey(key))
        {
            int oldQuantity=((ProductCart)this.get(key)).getQuan();
            ((ProductCart)this.get(key)).setQuan(oldQuantity+1);
        }
        else
        {
            this.put(prod.getProd().getCode(), prod);
        }
    }
    
    public boolean removeProd(String code)
    {
        if(this.containsKey(code))
        {
            this.remove(code);
            return true;
        }
        else
        {
            return false;
        }
    }
    
}

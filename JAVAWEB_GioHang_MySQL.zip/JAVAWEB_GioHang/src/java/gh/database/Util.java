/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gh.database;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author mac
 */
public class Util {
    private static Connection connection;
    //dinh nghia ham ket noi csdl
    public static synchronized Connection getConnection()
    {
        String strCon = "jdbc:mysql://localhost/DB";
        String user="root"; //"root"
        String pass="sesame";//""
        if(connection!=null)
        {
            return connection;
        }
        else {
            try {

                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(strCon, user, pass);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
    public static synchronized void closeConnection()
    {
        if(connection!=null)
        {
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            finally{
                connection=null;
            }
        }
    }
    
}

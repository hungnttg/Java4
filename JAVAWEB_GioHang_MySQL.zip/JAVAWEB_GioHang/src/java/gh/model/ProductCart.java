/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gh.model;

import java.io.Serializable;

/**
 *
 * @author mac
 */
public class ProductCart implements Serializable{
    private Product prod;
    private int quan;

    public ProductCart() {
    }

    public ProductCart(Product prod) {
        this.prod = prod;
    }
    
    

    public Product getProd() {
        return prod;
    }

    public void setProd(Product prod) {
        this.prod = prod;
    }

    public int getQuan() {
        return quan;
    }

    public void setQuan(int quan) {
        this.quan = quan;
    }
    
    
}

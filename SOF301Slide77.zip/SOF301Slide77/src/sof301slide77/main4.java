/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sof301slide77;

import model.LopDAO;

/**
 *
 * @author Administrator
 */
public class main4 {
    public static void main(String[] args) {
        if(LopDAO.deleteLop("12E"))
            System.out.println("Xoa thanh cong!");
        else
            System.out.println("Xoa that bai!"); 

    }
}

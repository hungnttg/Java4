/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sof301slide77;

import entity.xml.Hocsinh;
import entity.xml.Lop;
import java.util.Iterator;
import model.LopDAO;

/**
 *
 * @author Administrator
 */
public class main5 {
    public static void main(String[] args) {
        Lop lop = LopDAO.layThongTinLop("10A");
        System.out.println("Mã lớp: " + lop.getMaLop());
        System.out.println("Tên lớp: " + lop.getTenLop());
        System.out.println("--------------------------------");
        
        Lop[] hocsinhlop = LopDAO.searchHocsinhLop("10A");
        int stt=1;
        for(Lop lops: hocsinhlop){
            for(Hocsinh hs: lops.getHocsinhs()){
                System.out.println("Hoc sinh thu: "+(stt++));
                System.out.println("Ma hoc sinh: "+ hs.getMaHocSinh());
                System.out.println("Ten Hoc sinh: "+hs.getTenHocSinh());
                System.out.println("------------");
            }                        
        }        
        

    }
}

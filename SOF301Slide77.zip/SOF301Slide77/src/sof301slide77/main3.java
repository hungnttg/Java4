/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sof301slide77;

import entity.xml.Hocsinh;
import entity.xml.Lop;
import model.HocsinhDAO;

/**
 *
 * @author Administrator
 */
public class main3 {
    public static void main(String[] args) {
        Hocsinh hs = new Hocsinh(7, "Minh Thuan", null);
        Lop lop = new Lop("12E", "Lop 12 chuyen Hoa");
        
        hs.setLop(lop);
        if(HocsinhDAO.themHocsinh(hs))
        {
            System.out.println("Thêm thành công!");            
        }
        else
            System.out.println("Thêm that bai!");       
    }
}

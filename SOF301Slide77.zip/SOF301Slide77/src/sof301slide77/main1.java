/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sof301slide77;

import entity.xml.Hocsinh;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.HibernateUtil;

/**
 *
 * @author Administrator
 */
public class main1 {
    public static void main(String[] args) {
        Hocsinh hs = null;
        SessionFactory ssFac = HibernateUtil.getSessionFactory();
        Session ss = ssFac.openSession();
        ss.getTransaction().begin();
        try{
            hs = (Hocsinh)ss.get(Hocsinh.class, 1);
//            System.out.println("Ten Hoc sinh: "+hs.getTenHocSinh());
//            System.out.println("Ma lop: "+hs.getLop().getMaLop());
//            System.out.println("Ten lop: "+hs.getLop().getTenLop());
        }catch(HibernateException e){
            System.out.println(e.getMessage());
        }finally{
            ss.close();
        }
        
        System.out.println("Ten Hoc sinh: "+hs.getTenHocSinh());
        System.out.println("Ma lop: "+hs.getLop().getMaLop());
        System.out.println("Ten lop: "+hs.getLop().getTenLop());
    }
}

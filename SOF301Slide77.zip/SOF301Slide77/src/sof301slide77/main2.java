/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sof301slide77;

import entity.xml.Hocsinh;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.HibernateUtil;

/**
 *
 * @author Administrator
 */
public class main2 {
    public static void main(String[] args) {
        Hocsinh hs = null;
        SessionFactory ssFac = HibernateUtil.getSessionFactory();
        Session ss = ssFac.openSession();
        ss.getTransaction().begin();
        try {         
            String hql="select hs from Hocsinh hs left join fetch hs.lop "
                    + "where hs.maHocSinh = :maHocSinh"; 
            Query query=ss.createQuery(hql); 
            query.setInteger("maHocSinh", 1); 
            hs = (Hocsinh) query.uniqueResult();       
        } catch (HibernateException ex) {
            System.out.println(ex.getMessage());
        } finally {
            ss.close();
        }
        System.out.println("Tên họcc sinh: " + hs.getTenHocSinh());   
        System.out.println("Mã danh mục: " + hs.getLop().getMaLop());
        System.out.println("Tên danh mục: " + hs.getLop().getTenLop()); 
    }
}

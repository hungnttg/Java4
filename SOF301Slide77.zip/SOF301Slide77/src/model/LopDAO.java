/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entity.xml.Lop;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import util.HibernateUtil;

/**
 *
 * @author Administrator
 */
public class LopDAO {
    public static Lop layThongTinLop(String malop){
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Lop lop = (Lop)session.get(Lop.class, malop);
        session.close();
        return lop;
    }
    public static boolean deleteLop(String malop){
        Lop lop = LopDAO.layThongTinLop(malop);
        if(lop==null)
            return false;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        try{
            session.getTransaction().begin();
            session.delete(lop);
            session.getTransaction().commit();
            return true;
        }catch(Exception e){
            session.getTransaction().rollback();
            System.out.println(e);
            return false;
        }
    }
    public static Lop layThongTinLops(String maLop){
        Lop lop = null;
        SessionFactory ssFac = HibernateUtil.getSessionFactory();
        Session ss = ssFac.getCurrentSession();
        Transaction trans = ss.getTransaction();
        trans.begin();
        try {
            lop = (Lop)ss.get(Lop.class, maLop);
            trans.commit();
        } catch (HibernateException ex ) {           
            System.out.println(ex.getMessage());
        }
        return lop;
    }
    public static Lop[] searchHocsinhLop(String malop){
        Transaction trans = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try{
            trans = session.getTransaction();
            trans.begin();
            String sql = "From Lop where maLop like ?";
            Query query = session.createQuery(sql);
            query.setString(0, "%"+malop+"%");
            List list = query.list();
            Lop[] result = new Lop[list.size()];
            list.toArray(result);
            trans.commit();
            return result;
        }catch(Exception e){
            if(trans.isActive()){
                trans.rollback();
            }
            e.printStackTrace();
        }
        return null;
    }
}

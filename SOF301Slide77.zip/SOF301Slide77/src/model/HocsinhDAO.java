/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entity.xml.Hocsinh;
import org.hibernate.Session;
import util.HibernateUtil;

/**
 *
 * @author Administrator
 */
public class HocsinhDAO {
     public static Hocsinh layThongHocSinh(int maHocsinh){
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Hocsinh kh = (Hocsinh)session.get(Hocsinh.class, maHocsinh);
        session.close();
        return kh;
    }
    public static boolean themHocsinh(Hocsinh hs){
        if(HocsinhDAO.layThongHocSinh(hs.getMaHocSinh())!=null)
            return false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try{
            session.beginTransaction();
            session.save(hs);
            session.getTransaction().commit();
            return true;
        }catch(Exception e){
            session.getTransaction().rollback();
            System.out.println(e);
            return false;
        }finally{
            session.close();
        }
    }
}

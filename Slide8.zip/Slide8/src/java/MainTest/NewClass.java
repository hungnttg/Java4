/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainTest;

import entity.Sach;
import entity.SachTacgia;
import entity.Tacgia;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import util.HibernateUtil;

/**
 *
 * @author Administrator
 */
public class NewClass {
    public static void main(String[] args) {
        
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        
//        List<Sach> list = null;
//        String sql="FROM Sach";
//        Query query = session.createQuery(sql);   
//        list = query.list(); 
//        for(Sach s: list){
//            System.out.println(s.getMaSach()+"\t"+s.getTenSach()+"\t"+s.getGia());
//        }
//-------
//        List<Sach> list = null;
//        String sql="FROM Sach";
//        Query query = session.createQuery(sql);   
//        query.setFirstResult(0);
//        query.setMaxResults(3);
//        list = query.list(); 
//        for(Sach s: list){
//            System.out.println(s.getMaSach()+"\t"+s.getTenSach()+"\t"+s.getGia());
//        }
//--------
//        String sql = "select s.maSach, s.tenSach, s.tacgia, s.gia from Sach s "
//                + "inner join s.tacgia";
//        Query query = session.createQuery(sql);
//        List<Object[]> ds = query.list();
//        for(int i=0;i<ds.size();i++){
//            Object[] obj = ds.get(i);
//            int masach = (int) obj[0];
//            String tensach = (String)obj[1];
//            Tacgia tg = (Tacgia)obj[2];
//            int gia = (int)obj[3];
//            System.out.println(masach+"\t"+tensach+"\t"+tg.getTenTacgia()+"\t"+gia);
//        }
//---------
//        List<Tacgia> list = null;
//        String sql="select s.tacgia FROM Sach s";
//        Query query = session.createQuery(sql);   
//        list = query.list();
//        for(Tacgia s: list){            
//            System.out.println(s.getMaTg()+"\t"+s.getTenTacgia());
//        }
//---------
//        String sql = "select s.maSach, s.tenSach, s.tacgia from Sach s";
//        Query query = session.createQuery(sql);
//        List<Object[]> ds = query.list();
//        for(int i=0;i<ds.size();i++){
//            Object[] obj = ds.get(i);
//            int masach = (int) obj[0];
//            String tensach = (String)obj[1];
//            Tacgia tg = (Tacgia)obj[2];
//            System.out.println(masach+"\t"+tensach+"\t"+tg.getTenTacgia());
//        }
//-----------
//        String sql = "select new entity.SachTacgia(s.maSach, s.tacgia.tenTacgia, s.tenSach, s.gia)  from Sach s";
//        Query query = session.createQuery(sql);
//        List<SachTacgia> ds = query.list();
//        System.out.println("Ma Sach\tTen Sach\tGia\tTac gia");
//        for(int i=0;i<ds.size();i++){
//            SachTacgia my = ds.get(i);
//            int masach = my.getMaSach();
//            String tensach = my.getTenSach();
//            int gia = my.getGia();
//            String tg = my.getTacgia();            
//            System.out.println(masach+"\t"+tensach+"\t"+gia+"\t"+tg);
//        }
//------------avg(), min(), max(), ...
//        String sql = "select avg(s.gia) as GiaTB, count(*) as SoLuongSach, min(s.gia) as GiaThapNhat, "
//                + "max(s.gia) as GiaCaoNhat, sum(s.soLuong) as TongSoLuongSach  from Sach s";
//        Query query = session.createQuery(sql);
//        Object[] ds = (Object[])query.uniqueResult();
//        System.out.println("GiaTB\tSoLuong\tGiaMin\tGiaMax\tTongSach");       
//        double GiaTB =(double) ds[0];
//        long SoLuong = (Long) ds[1];
//        int GiaMin = (Integer) ds[2];
//        int GiaMax = (Integer) ds[3];
//        long TongSLSach = (Long) ds[4];               
//        System.out.println(GiaTB+"\t"+SoLuong+"\t"+GiaMin+"\t"+GiaMax+"\t"+TongSLSach);
        
//---------- where-- order by ...
//        List<Sach> list = null;
//        String tensach="";
//        String sql="from Sach s where s.tenSach like :tenSach";
//        //String sql="from Sach s order by s.maSach ASC";
//        Query query = session.createQuery(sql);   
//        query.setString("tenSach","%"+tensach+"%");
//        list = query.list();       
//        for(Sach s: list){
//            System.out.println(s.getMaSach()+"\t"+s.getTenSach()+"\t"+s.getGia());            
//        }
//---------------

//        String sql = "DELETE FROM Sach s WHERE s.maSach = :maSach";
//        Query query = session.createQuery(sql);
//        query.setParameter("maSach", 6);
//        int result = query.executeUpdate();
//        session.getTransaction().commit();
        
        session.close();
    }       
        
    
}

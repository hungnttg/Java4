/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Sach;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import util.HibernateUtil;

/**
 *
 * @author Administrator
 */
public class SachDAO {
     public static List<Sach> laySach(String ten){
        List<Sach> list = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String sql="FROM Sach";
        Query query=null;
        if(ten.length()>0){
            sql += " where tenSach like '%"+ten+"%'";
            //sql += " where tenSach = :maKhachHang"; 
            query = session.createQuery(sql);
            //query.setParameter("maKhachHang", tenkh);
        }else{
            query = session.createQuery(sql);
            query.setFirstResult(0);
            query.setMaxResults(3);
        }       
        list = query.list();
        return list;
    }    
}
